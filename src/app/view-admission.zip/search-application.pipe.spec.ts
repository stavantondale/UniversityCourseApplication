import { SearchApplicationPipe } from './search-application.pipe';

describe('SearchApplicationPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchApplicationPipe();
    expect(pipe).toBeTruthy();
  });
});
