enum AdmissionStatus{
    APPLIED,
	PENDING,
	CONFIRMED,
	REJECTED
}